document.addEventListener("DOMContentLoaded", function () {
    // Simpan urutan asli produk
    const productContainer = document.getElementById('product-container');
    const originalProducts = Array.from(productContainer.children);
    const sortNotification = document.querySelector('.sort-notification');
    
    // Fungsi untuk ekstrak harga dari string
    function extractPrice(priceString) {
        // Hapus 'Rp ' dan semua titik, lalu ubah ke integer
        const cleanString = priceString.replace('Rp ', '').replace(/\./g, '');
        return parseInt(cleanString);
    }
    
    // Fungsi untuk menampilkan notifikasi sorting
    function showSortNotification(message) {
        const alertElement = sortNotification.querySelector('.alert');
        alertElement.innerHTML = `<strong>${message}</strong> Produk telah diurutkan. 
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>`;
        
        sortNotification.classList.add('show');
        
        setTimeout(() => {
            sortNotification.classList.remove('show');
        }, 3000);
    }

    // Fungsi sorting produk
    function sortProducts(order) {
        const products = Array.from(productContainer.querySelectorAll('.product-item'));
        
        products.sort((a, b) => {
            const priceA = extractPrice(a.querySelector('.price').textContent);
            const priceB = extractPrice(b.querySelector('.price').textContent);
            
            if (order === 'low') {
                return priceA - priceB; // Terendah ke Tertinggi
            } else if (order === 'high') {
                return priceB - priceA; // Tertinggi ke Terendah
            }
            return 0;
        });
        
        // Bersihkan container dan tambahkan produk yang sudah diurutkan
        productContainer.innerHTML = '';
        products.forEach(product => productContainer.appendChild(product));
        
        // Tampilkan notifikasi
        if (order === 'low') {
            showSortNotification('Harga Terendah ke Tertinggi');
        } else if (order === 'high') {
            showSortNotification('Harga Tertinggi ke Terendah');
        }
    }

    // Event listener untuk dropdown sort
    document.getElementById('sort-by').addEventListener('change', function() {
        switch(this.value) {
            case 'low':
                sortProducts('low');
                break;
            case 'high':
                sortProducts('high');
                break;
            case 'rating':
                // Kembalikan ke urutan semula untuk rating
                productContainer.innerHTML = '';
                originalProducts.forEach(product => productContainer.appendChild(product));
                showSortNotification('Rating Tertinggi');
                break;
            default:
                // Kembalikan ke urutan semula
                productContainer.innerHTML = '';
                originalProducts.forEach(product => productContainer.appendChild(product));
                showSortNotification('Urutan Default');
        }
    });

  // Toggle Grid/List View
const gridViewBtn = document.getElementById('grid-view-btn');
const listViewBtn = document.getElementById('list-view-btn');

if (gridViewBtn && listViewBtn && productContainer) {
    // Set default view to grid
    productContainer.classList.add('grid-view');
    gridViewBtn.classList.add('active');

    gridViewBtn.addEventListener('click', () => {
        if (!gridViewBtn.classList.contains('active')) {
            productContainer.classList.remove('list-view');
            productContainer.classList.add('grid-view');
            gridViewBtn.classList.add('active');
            listViewBtn.classList.remove('active');
            
            // Reset to grid layout
            document.querySelectorAll('.product-item').forEach(item => {
                item.className = 'col-xl-3 col-lg-4 col-md-6 product-item mb-4';
                item.style.display = ''; // Reset display if hidden by filter
                
                // Reset image container
                const imgContainer = item.querySelector('.card > div');
                if (imgContainer) {
                    imgContainer.style.width = '';
                    imgContainer.style.height = '';
                }
            });
        }
    });

    listViewBtn.addEventListener('click', () => {
        if (!listViewBtn.classList.contains('active')) {
            productContainer.classList.remove('grid-view');
            productContainer.classList.add('list-view');
            listViewBtn.classList.add('active');
            gridViewBtn.classList.remove('active');
            
            // Change to list layout
            document.querySelectorAll('.product-item').forEach(item => {
                item.className = 'product-item mb-4';
                item.style.display = ''; // Reset display if hidden by filter
                
                // Adjust image container for list view
                const imgContainer = item.querySelector('.card > div');
                if (imgContainer) {
                    imgContainer.style.width = '150px';
                    imgContainer.style.height = '150px';
                }
            });
        }
    });
}

    // Quantity selector in modal
    document.addEventListener('click', function (e) {
        if (e.target.classList.contains('minus-btn')) {
            const input = e.target.parentElement.querySelector('.quantity-input');
            if (input && parseInt(input.value) > 1) {
                input.value = parseInt(input.value) - 1;
            }
        }

        if (e.target.classList.contains('plus-btn')) {
            const input = e.target.parentElement.querySelector('.quantity-input');
            if (input) {
                input.value = parseInt(input.value) + 1;
            }
        }
    });

    // Color selector in modal
    document.addEventListener('click', function (e) {
        const colorBtn = e.target.closest('.color-options .btn');
        if (colorBtn) {
            document.querySelectorAll('.color-options .btn').forEach(b => b.classList.remove('active'));
            colorBtn.classList.add('active');
        }
    });

    // Size selector in modal
    document.addEventListener('click', function (e) {
        const sizeBtn = e.target.closest('.size-options .btn');
        if (sizeBtn) {
            document.querySelectorAll('.size-options .btn').forEach(b => b.classList.remove('active'));
            sizeBtn.classList.add('active');
        }
    });

    // Add to cart animation
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            this.innerHTML = '<i class="fas fa-check"></i>';
            this.classList.remove('btn-outline-dark');
            this.classList.add('btn-success');

            setTimeout(() => {
                this.innerHTML = '<i class="fas fa-plus"></i>';
                this.classList.remove('btn-success');
                this.classList.add('btn-outline-dark');
            }, 1500);
        });
    });

    // Filter by category
    const categoryFilter = document.getElementById("category-filter");
    const products = document.querySelectorAll(".product-item");

    categoryFilter.addEventListener("change", function () {
        const selectedCategory = this.value;

        products.forEach(product => {
            const category = product.getAttribute("data-category");

            if (selectedCategory === "Semua Kategori" || selectedCategory === category) {
                product.style.display = "block";
            } else {
                product.style.display = "none";
            }
        });
    });

    // Search functionality
    const searchInput = document.getElementById("search-input");
    const searchButton = document.getElementById("search-button");

    searchButton.addEventListener("click", function () {
        const keyword = searchInput.value.toLowerCase();
        const products = document.querySelectorAll(".product-item");

        products.forEach(product => {
            const title = product.getAttribute("data-title").toLowerCase();
            if (title.includes(keyword)) {
                product.style.display = "block";
            } else {
                product.style.display = "none";
            }
        });
    });

    searchInput.addEventListener("keyup", function (e) {
        if (e.key === "Enter") {
            searchButton.click();
        }
    });

    // Mobile menu toggle (fixed syntax error)
    function toggleMenu() {
        document.getElementById('navLinks').classList.toggle('active');
    }
});
